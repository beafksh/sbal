package com.example.beafk.sbal.Login;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.PaintDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.beafk.sbal.Db.DBHelper;
import com.example.beafk.sbal.MainActivity;
import com.example.beafk.sbal.R;

import static com.example.beafk.sbal.R.id.userlist;

public class preMainActivity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    int clubintent;

    boolean id_gen_check=false;
    DBHelper dbHelper = new DBHelper(this, "sbal", null, 1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_premain);

    }

    public void new_memberClick(View v){

        nameintent= null;
        id_gen_check = false;
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.new_member, null);
        builder.setView(view);
        final EditText temptext = (EditText)view.findViewById(R.id.name_insert);

        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(true);


        builder.setPositiveButton("Login",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        nameintent = temptext.getText().toString();
                        if(nameintent.length() <= 0 || id_gen_check==false)
                        {
                            String m = "성명확인 및 ID를 생성해주세요" ;
                            Toast toast = Toast.makeText(getApplicationContext(),m, Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();

                        }
                        else {
                            dbHelper.login_insert(idintent,nameintent);
                            Intent intent = new Intent(preMainActivity.this, MainActivity.class);
                            intent.putExtra("id", idintent);
                            intent.putExtra("name", nameintent);
                            intent.putExtra("pro",prointent);
                            clubintent=1;
                            intent.putExtra("club",clubintent);
                            startActivity(intent);
                        }
                    }
                }
        );
        builder.setNegativeButton("CANCLE",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                }
        );


        builder.show();
    }

    public void existing_memberClick(View v){

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.existing_member, null);

        /////사용자 리스트 추가코드
        final ListView userlistview ;
        userListViewAdapter adapter;
        // Adapter 생성
        adapter = new userListViewAdapter() ;
        // 리스트뷰 참조 및 Adapter달기
        userlistview = (ListView)view.findViewById(userlist);
        userlistview.setAdapter(adapter);
        userlistview.setSelector( new PaintDrawable( 0xAA008B8B )) ;

        ////////////////////db에서 사용자 목록 가져와서 출력하는 부분
        SQLiteDatabase db = dbHelper.login_connect_db();
        userdata userlist = new userdata("","");
        // DB에 있는 데이터를 쉽게 처리하기 위해 Cursor를 사용하여 테이블에 있는 모든 데이터 출력
        Cursor cursor = db.rawQuery("SELECT * FROM user", null);
        while (cursor.moveToNext()) {
            int a= cursor.getInt(0);
            String temp = String.valueOf(a);
            String id = temp;
            String name = cursor.getString(1);
            /////////////////////////////만들어서 넣어주는 부분
            adapter.addItem(id, name) ;
        }
        ////////////////////////////////////////////////////////////////

        userlistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // get item
                userListViewItem item = (userListViewItem) parent.getItemAtPosition(position) ;

                String sel_id = item.getid() ;
                String sel_name = item.getname() ;

                idintent = sel_id;
                nameintent = sel_name;

                Toast toast = Toast.makeText(getApplicationContext(),sel_name, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();

                // TODO : use item data.
            }
        }) ;

        ////////////////////////////////

        builder.setView(view);
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(true);
        builder.setPositiveButton("Login",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        if(nameintent ==null) {
                            String m = "리스트에서 선택해주세요";
                            Toast toast = Toast.makeText(getApplicationContext(), m, Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        }
                        else {
                            SQLiteDatabase db = dbHelper.login_connect_db();
                            // DB에 있는 데이터를 쉽게 처리하기 위해 Cursor를 사용하여 테이블에 있는 모든 데이터 출력
                            int idtemp = Integer.parseInt(idintent);
                            Cursor cursor = db.rawQuery("SELECT * FROM user where id="+idtemp+";", null);
                            while (cursor.moveToNext()) {
                                int a= cursor.getInt(0);
                                prointent= cursor.getString(2);
                            }
                            Intent intent = new Intent(preMainActivity.this, MainActivity.class);
                            clubintent=1;
                            intent.putExtra("id", idintent);
                            intent.putExtra("name", nameintent);
                            intent.putExtra("pro",prointent);
                            intent.putExtra("club",clubintent);
                            startActivity(intent);
                        }

                    }
                }
        );
        builder.setNegativeButton("CANCLE",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                }
        );

        builder.show();

    }



    public void id_generate(View v){

        id_gen_check=true;

        /*
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.new_member, null);
        builder.setView(layout);

        AlertDialog dialog = builder.create();
        */

        SQLiteDatabase db = dbHelper.login_connect_db();

        Cursor cursor = db.rawQuery("SELECT * FROM user", null);

        int temp = cursor.getCount();

        String stemp = String.valueOf(temp);

        idintent = stemp;
        String a = "생성된 ID : "+idintent ;

        Toast toast = Toast.makeText(getApplicationContext(),a, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();

    }



}
