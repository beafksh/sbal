package com.example.beafk.sbal.Custom;

/**
 * Created by Philipp Jahoda on 07/12/15.
 */
public class ContentItem {

    String name;
    boolean isNew = false;

    public ContentItem(String n, String d) {
        name = n;
    }
}
