package com.example.beafk.sbal.Db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


/**
 * Created by beafk on 2017-03-31.
 */

public class DBHelper extends SQLiteOpenHelper {

    public int[] weight = new int[12];

    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    // DB를 새로 생성할 때 호출되는 함수
    @Override
    public void onCreate(SQLiteDatabase db) {
        //무쓸모

        //db.execSQL("create table if not exists user(id int, name char(15));");
        //db.execSQL("INSERT INTO user VALUES(0,'aaa');");
    }

    // DB 업그레이드를 위해 버전이 변경될 때 호출되는 함수
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void login_insert(String id, String name) {
        // 읽고 쓰기가 가능하게 DB 열기
        int temp = Integer.parseInt(id);
        String temp2 = "null";
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor1 = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name ='user'" , null);


        cursor1.moveToFirst();

        if(cursor1.getCount()==0){
            db.execSQL("create table user(id int, name char(15), sp char(15));");
            db.execSQL("INSERT INTO user VALUES(0,'aaa','null');");
        }
        // DB에 입력한 값으로 행 추가
        db.execSQL("INSERT INTO user VALUES(" + temp + ", '" + name + "','" +temp2+ "');");

        db.close();
    }

    public void user_swingdata_insert(int club) {
        // 읽고 쓰기가 가능하게 DB 열기

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor1 = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name ='user_swingdata'" , null);
        Cursor cursor = db.rawQuery("SELECT * FROM user_swingdata", null);
        int no = cursor.getCount();

        cursor1.moveToFirst();

        if(cursor1.getCount()==0){
            db.execSQL("create table user_swingdata(no int, club int, one, two, three, four, five, six, seven, eight, nine, ten);");
            db.execSQL("INSERT INTO user_swingdata VALUES("+no+","+club+",10,10,10,10,10,10,10,10,10,10);");

        }
        // DB에 입력한 값으로 행 추가
        db.execSQL("INSERT INTO user_swingdata VALUES("+no+","+club+","+weight[2]+","+weight[3]+","+weight[4]+","+weight[5]+","+weight[6]+","+weight[7]+","+weight[8]+","+weight[9]+","+weight[10]+","+weight[11]+");");
        db.close();
    }

    /*
        public void update(String item, int price) {
            SQLiteDatabase db = getWritableDatabase();
            // 입력한 항목과 일치하는 행의 가격 정보 수정
            db.execSQL("UPDATE MONEYBOOK SET price=" + price + " WHERE item='" + item + "';");
            db.close();
        }

        public void delete(String item) {
            SQLiteDatabase db = getWritableDatabase();
            // 입력한 항목과 일치하는 행 삭제
            db.execSQL("DELETE FROM MONEYBOOK WHERE item='" + item + "';");
            db.close();
        }
    */

    public SQLiteDatabase login_connect_db() {
        // 읽기가 가능하게 DB 열기
        SQLiteDatabase db = getReadableDatabase();

        //db table없으면 만들어서 기본 1명 (0, aaa) 집어넣어라
        Cursor cursor1 = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name ='user'" , null);
        cursor1.moveToFirst();

        if(cursor1.getCount()==0){
            db.execSQL("create table user(id int, name char(15), sp char(15));");
            db.execSQL("INSERT INTO user VALUES(0,'aaa','null');");
        }

        return db;
    }


    public SQLiteDatabase user_swingdata_connect_db() {
        // 읽기가 가능하게 DB 열기
        SQLiteDatabase db = getReadableDatabase();

        //db table없으면 만들어서 기본 1명 (0, aaa) 집어넣어라
        Cursor cursor1 = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name ='user_swingdata'" , null);
        cursor1.moveToFirst();

        int temp = cursor1.getCount();
        int club = 1;

        if(cursor1.getCount()==0){
            db.execSQL("create table user_swingdata(no int, club int, one, two, three, four, five, six, seven, eight, nine, ten);");
            db.execSQL("INSERT INTO user_swingdata VALUES("+temp+","+club+",10,10,10,10,10,10,10,10,10,10);");
        }

        return db;
    }

    public SQLiteDatabase pro_swingdata_connect_db() {
        // 읽기가 가능하게 DB 열기
        SQLiteDatabase db = getReadableDatabase();

        //db table없으면 만들어서 기본 1명 (0, aaa) 집어넣어라
        Cursor cursor1 = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name ='pro_swingdata'" , null);
        cursor1.moveToFirst();

        if(cursor1.getCount()==0){
            db.execSQL("create table pro_swingdata(name char(15), club int, one, two, three, four, five, six, seven, eight, nine, ten);");
            db.execSQL("INSERT INTO pro_swingdata VALUES('최경주',1,23,34,54,75,65,55,42,33,22,11);");
            db.execSQL("INSERT INTO pro_swingdata VALUES('최경주',7,19,45,65,73,81,69,43,29,19,10);");
            db.execSQL("INSERT INTO pro_swingdata VALUES('박세리',1,31,19,24,44,49,55,49,42,30,24);");
            db.execSQL("INSERT INTO pro_swingdata VALUES('박세리',7,22,43,75,33,54,48,27,82,33,10);");
            db.execSQL("INSERT INTO pro_swingdata VALUES('박인비',1,74,45,22,86,54,11,5,23,43,45);");
            db.execSQL("INSERT INTO pro_swingdata VALUES('박인비',7,65,43,34,78,29,16,97,63,26,32);");
        }

        return db;
    }

    public SQLiteDatabase pro_set(int id, String sel_pro) {
        // 읽기가 가능하게 DB 열기
        SQLiteDatabase db = getReadableDatabase();

        //db table없으면 만들어서 기본 1명 (0, aaa) 집어넣어라
        Cursor cursor1 = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name ='user'" , null);
        cursor1.moveToFirst();

        db.execSQL("UPDATE user set sp='"+sel_pro+"' where id="+id+";");

        return db;
    }


}
