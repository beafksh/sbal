package com.example.beafk.sbal.PV;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.beafk.sbal.MainActivity;
import com.example.beafk.sbal.R;

public class PVActivity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    int clubintent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pv);
        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        prointent = intent.getStringExtra("pro");
        clubintent = intent.getIntExtra("club",1);

        /////사용자 리스트 추가코드
        final ListView replaylistview ;
        replayListViewAdapter adapter;
        // Adapter 생성
        adapter = new replayListViewAdapter() ;
        // 리스트뷰 참조 및 Adapter달기
        replaylistview = (ListView)findViewById(R.id.replay_list);
        replaylistview.setAdapter(adapter);
        replaylistview.setSelector( new PaintDrawable( 0xAA008B8B )) ;

        Drawable test = ContextCompat.getDrawable(this, R.drawable.plus_icon);
        //다이얼로그이면 this 대신 v.getContext() 써야함
        String temp ="2017-10-21 18:00";
        /////////////////////////////만들어서 넣어주는 부분
        adapter.addItem(test, temp) ;
        adapter.addItem(test, temp) ;
        adapter.addItem(test, temp) ;
        adapter.addItem(test, temp) ;


        ///리스트 클릭 이벤트
        replaylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // get item
                replayListViewItem item = (replayListViewItem) parent.getItemAtPosition(position) ;
                String sel_id = item.getTitle() ;
                Toast toast = Toast.makeText(getApplicationContext(),sel_id, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();

                // TODO : use item data.
            }
        }) ;

        ////////////////////////////////////////////////////////////////
    }

    public void go_main(View v) {
        Intent intent = new Intent(PVActivity.this,MainActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        startActivity(intent);
    }


}
