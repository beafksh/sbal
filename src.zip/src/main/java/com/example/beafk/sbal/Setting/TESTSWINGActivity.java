package com.example.beafk.sbal.Setting;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.example.beafk.sbal.MainActivity;
import com.example.beafk.sbal.R;


public class TESTSWINGActivity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    int clubintent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_swing);

        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        prointent = intent.getStringExtra("pro");
        clubintent = intent.getIntExtra("club",1);

        EditText editText1 = (EditText) findViewById(R.id.editText1);
        EditText editText2 = (EditText) findViewById(R.id.editText2);
        editText1.setFocusable(false);
        editText1.setClickable(false);
        editText2.setFocusable(false);
        editText2.setClickable(false);
    }

    public void go_main(View v) {
        Intent intent = new Intent(TESTSWINGActivity.this,MainActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        startActivity(intent);
    }

    public void start_test_swing(View v) {
        Intent intent =  new Intent(TESTSWINGActivity.this,TESTSWING1Activity.class);   // main.java 파일에서 이벤트를 발생시켜서 test를 불러옵니다.
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        startActivity(intent);
    }

}