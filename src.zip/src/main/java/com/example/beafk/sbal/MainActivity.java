package com.example.beafk.sbal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.example.beafk.sbal.Login.preMainActivity;
import com.example.beafk.sbal.PS.prePSActivity;
import com.example.beafk.sbal.PV.PVActivity;
import com.example.beafk.sbal.Setting.TESTSWINGActivity;

public class MainActivity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    int clubintent;

    TextView name_space;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /////////////////////~~님 설정
        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        prointent = intent.getStringExtra("pro");
        clubintent = intent.getIntExtra("club",1);

        name_space = (TextView)findViewById(R.id.hi);
        name_space.setText(nameintent+"님 안녕하세요");
        ///////////////////////////////////////
    }

    public void ps_Click(View v){
        Intent intent = new Intent(MainActivity.this,prePSActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);

        startActivity(intent);
    }

    public void pv_Click(View v){
        Intent intent = new Intent(MainActivity.this,PVActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        startActivity(intent);
    }

    public void testswing_Click(View v){
        Intent intent = new Intent(MainActivity.this,TESTSWINGActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);

        startActivity(intent);
    }

    public void logout(View v) {
        Intent intent = new Intent(MainActivity.this,preMainActivity.class);
        startActivity(intent);
    }




}
