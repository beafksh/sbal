package com.example.beafk.sbal.Setting;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.beafk.sbal.Db.DBHelper;
import com.example.beafk.sbal.MainActivity;
import com.example.beafk.sbal.R;

/**
 * Created by jinye on 2017-03-22.
 */

public class TESTSWING2Activity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    String first;
    String second;
    String third;
    int clubintent;
    int maxcorrect;

    DBHelper dbHelper = new DBHelper(this, "sbal", null, 1);

    ImageView iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_swing2);

        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        prointent = intent.getStringExtra("pro");
        clubintent = intent.getIntExtra("club",1);
        first = intent.getStringExtra("first");
        second = intent.getStringExtra("second");
        third = intent.getStringExtra("third");
        maxcorrect = intent.getIntExtra("max",100);


        iv = (ImageView)findViewById(R.id.best_pro);
        if(first.equals("최경주"))
        {
            iv.setImageResource(R.drawable.cgj);
        }
        else if(first.equals("박세리"))
        {
            iv.setImageResource(R.drawable.psr);
        }
        else if(first.equals("박인비"))
        {
            iv.setImageResource(R.drawable.pib);
        }

        EditText editText4 = (EditText) findViewById(R.id.editText4);
        editText4.setFocusable(false);
        editText4.setClickable(false);
        EditText editText5 = (EditText) findViewById(R.id.editText5);
        editText5.setFocusable(false);
        editText5.setClickable(false);

        String maxtemp = String.valueOf(maxcorrect);

        editText5.setText(first+ "선수 "+maxtemp+"% 입니다!");
    }

    public void other_pro_choice(View v){
        Intent intent =  new Intent(TESTSWING2Activity.this,TESTSWING3Activity.class);   // main.java 파일에서 이벤트를 발생시켜서 test를 불러옵니다.
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        intent.putExtra("first", first);
        intent.putExtra("second",second);
        intent.putExtra("third",third);
        intent.putExtra("max",maxcorrect);
        startActivity(intent);
    }

    public void go_main(View v) {
        Intent intent = new Intent(TESTSWING2Activity.this,MainActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        startActivity(intent);
    }

    public void pro_set(View v){
        Intent intent = new Intent(TESTSWING2Activity.this,MainActivity.class);

        prointent=first;
        int idtemp = Integer.parseInt(idintent);
        SQLiteDatabase db = dbHelper.pro_set(idtemp, prointent);

        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        startActivity(intent);
    }
}

