package com.example.beafk.sbal.PS;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.beafk.sbal.Custom.DayAxisValueFormatter;
import com.example.beafk.sbal.Custom.MyAxisValueFormatter;
import com.example.beafk.sbal.Custom.XYMarkerView;
import com.example.beafk.sbal.Db.DBHelper;
import com.example.beafk.sbal.MainActivity;
import com.example.beafk.sbal.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.Random;

import static java.lang.Boolean.TRUE;

public class PS1Activity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    int clubintent;

    DBHelper dbHelper = new DBHelper(this, "sbal", null, 1);

    private ProgressBar progBar;
    private TextView text;
    private Handler mHandler = new Handler();
    private int mProgressStatus=0;

    public int[][] user_weight = new int[10][2];
    public int[][] pro_weight = new int[10][2];

    private static int rate = 0;
    private static int rate2 = 0;
    private static int result = 0;

    TextView correct_space;

    public BarChart mChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ps1);

        SQLiteDatabase db = dbHelper.user_swingdata_connect_db();

        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        prointent = intent.getStringExtra("pro");
        clubintent = intent.getIntExtra("club",1);

        //데모선수데이터 생성
        SQLiteDatabase db2 = dbHelper.pro_swingdata_connect_db();
        // DB에 있는 데이터를 쉽게 처리하기 위해 Cursor를 사용하여 테이블에 있는 모든 데이터 출력
        Cursor cursor = db2.rawQuery("SELECT * FROM pro_swingdata where club="+clubintent+" and name='"+prointent+"'", null);
        while (cursor.moveToNext()) {
            for(int i=0;i<10;i++)
            {
                pro_weight[i][0]=cursor.getInt(i+2);
                pro_weight[i][1]=100-pro_weight[i][0];
            }
        }

        TextView proname = (TextView) findViewById(R.id.ps1_compare);
        proname.setText(prointent+" 선수와의 스윙 밸런스 일치도");

        progBar= (ProgressBar)findViewById(R.id.ps1_progressBar);
        //text = (TextView)findViewById(R.id.textView1);

        create_bar();

    }

    public void create_bar()
    {
        //막대그래프 색은 라이브러리 util-colortemplate-MATERIAL_COLORS

        mChart = (BarChart) findViewById(R.id.ps1_barchart);
        mChart.setDrawBarShadow(false);
        //mChart.setDrawValueAboveBar(true);
        mChart.getDescription().setEnabled(false);
        // if more than 60 entries are displayed in the chart, no values will be
        // drawn
        mChart.setMaxVisibleValueCount(60);
        // scaling can now only be done on x- and y-axis separately
        mChart.setPinchZoom(false);
        mChart.setDrawGridBackground(false);
        // mChart.setDrawYLabels(false);

        IAxisValueFormatter xAxisFormatter = new DayAxisValueFormatter(mChart);
        XAxis xAxis = mChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        //xAxis.setTypeface(mTfLight);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f); // only intervals of 1 day
        xAxis.setLabelCount(7);
        xAxis.setValueFormatter(xAxisFormatter);

        IAxisValueFormatter custom = new MyAxisValueFormatter();
        YAxis leftAxis = mChart.getAxisLeft();
        //leftAxis.setTypeface(mTfLight);
        leftAxis.setLabelCount(8, false);
        leftAxis.setValueFormatter(custom);
        leftAxis.setPosition(YAxis.YAxisLabelPosition.OUTSIDE_CHART);
        leftAxis.setSpaceTop(15f);
        leftAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)

        YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setDrawGridLines(false);
        //rightAxis.setTypeface(mTfLight);
        rightAxis.setLabelCount(8, false);
        rightAxis.setValueFormatter(custom);
        rightAxis.setSpaceTop(15f);
        rightAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)

        Legend l = mChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setDrawInside(false);
        l.setForm(Legend.LegendForm.SQUARE);
        l.setFormSize(9f);
        l.setTextSize(11f);
        l.setXEntrySpace(4f);

        XYMarkerView mv = new XYMarkerView(this, xAxisFormatter);
        mv.setChartView(mChart); // For bounds control
        mChart.setMarker(mv); // Set the marker to the chart

        /////////////////////////막대 갯수 및 막대의 데이터 값 범위
        setData(2, 50);
    }


    public void setData(int count, float range) {

        float start = 1f;
        ArrayList<BarEntry> yVals1 = new ArrayList<BarEntry>();
        for (int i = (int) start; i < start + count; i++) {
            float mult = (range + 1);
            float val = (float)(1);

            if (val == 1) {
                yVals1.add(new BarEntry(i, 50)); //값추가
            } else {
                yVals1.add(new BarEntry(i, 0)); //잘못되었을때 값
            }
        }
        BarDataSet set1;
        if (mChart.getData() != null &&
                mChart.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) mChart.getData().getDataSetByIndex(0);
            set1.setValues(yVals1);
            mChart.getData().notifyDataChanged();
            mChart.notifyDataSetChanged();
        } else {
            set1 = new BarDataSet(yVals1, "왼발 , 오른발");

            set1.setDrawIcons(TRUE);
            set1.setColors(ColorTemplate.MATERIAL_COLORS);

            ArrayList<IBarDataSet> dataSets = new ArrayList<IBarDataSet>();
            dataSets.add(set1);

            BarData data = new BarData(dataSets);
            data.setValueTextSize(10f);
            //data.setValueTypeface(mTfLight);
            data.setBarWidth(0.9f);

            mChart.setData(data);
        }
    }
    public void go_main(View v) {
        Intent intent = new Intent(PS1Activity.this,MainActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);

        startActivity(intent);
    }

    public void start(View v) {

        String temp="null";
        if(prointent.equals(temp))
        {
            String alert = "테스트 스윙 단계를 진행 필요!";
            Toast toast = Toast.makeText(getApplicationContext(),alert, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        else {
            int correct;

            for (int i = 0; i < 10; i++) {
                Random ran = new Random();
                dbHelper.weight[i + 2] = ran.nextInt(100);
            }

            dbHelper.user_swingdata_insert(clubintent);
            for (int i = 0; i < 10; i++) {
                user_weight[i][0] = dbHelper.weight[i + 2];
                user_weight[i][1] = 100 - dbHelper.weight[i + 2];
            }

            correct = compare(user_weight, pro_weight);
            fill_progress(correct);

            String stemp = String.valueOf(correct);
            correct_space = (TextView) findViewById(R.id.ps1_correct);
            correct_space.setText(stemp + "%");
            }
        }
        // 비교알고리즘

        public int compare(int mydata[][], int prodata[][]){

            //본격 비교하기 알고리즘//
            int[] comparerate = new int[10];
            int[] comparerate2 = new int[11];
            for(int i=0;i<9;i++){
                comparerate[i]=100-(Math.abs((mydata[i][0]-mydata[i+1][0])-(prodata[i][0]-prodata[i+1][0])));
                rate=rate+comparerate[i];
            }
            rate=rate/90;
            for(int j=0;j<10;j++){
                comparerate2[j]=100-(Math.abs(mydata[j][0]-prodata[j][0]));
                rate2=rate2+comparerate2[j];
            }
            rate2=rate2/100;
            result=rate*rate2;

        return result;
    }

    ////////////////////////////프로그래스바
    public void fill_progress(int correct) {

        final int pcorrect = correct;

        new Thread(new Runnable() {
            public void run() {
                final int presentage=0;
                while (mProgressStatus < pcorrect) {
                    mProgressStatus += 1;
                    // Update the progress bar
                    mHandler.post(new Runnable() {
                        public void run() {
                            progBar.setProgress(mProgressStatus);
                            //text.setText(""+mProgressStatus+"%");

                        }
                    });
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                while (mProgressStatus > pcorrect) {
                    mProgressStatus -= 1;
                    // Update the progress bar
                    mHandler.post(new Runnable() {
                        public void run() {
                            progBar.setProgress(mProgressStatus);
                            //text.setText(""+mProgressStatus+"%");

                        }
                    });
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    public void club_change(View v) {
            if(clubintent==1)
            {
                clubintent=7;
                String temp_club = String.valueOf(clubintent);
                String alert = temp_club+"번 클럽으로 전환되었습니다.";
                Toast toast = Toast.makeText(getApplicationContext(),alert, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
            else if(clubintent==7)
            {
                clubintent=1;
                String temp_club = String.valueOf(clubintent);
                String alert = temp_club+"번 클럽으로 전환되었습니다.";
                Toast toast = Toast.makeText(getApplicationContext(),alert, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
       }



}
