package com.example.beafk.sbal.Setting;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.example.beafk.sbal.Db.DBHelper;
import com.example.beafk.sbal.R;

import java.util.Random;

/**
 * Created by jinye on 2017-03-22.
 */

public class TESTSWING1Activity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    String first_pro;
    String second_pro;
    String third_pro;
    int maxcorrect;
    int clubintent;

    int test_num;
    int temp;
    TextView test;

    DBHelper dbHelper = new DBHelper(this, "sbal", null, 1);

    public int[][] user_weight = new int[10][2];
    public int[][] pro_weight = new int[10][2];
    public int[] correct = new int[3];

    private static int rate = 0;
    private static int rate2 = 0;
    private static int result = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_swing1);
        test_num=0;
        temp=0;

        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        prointent = intent.getStringExtra("pro");
        clubintent = intent.getIntExtra("club",1);

        /*
        Button btn2 = (Button) findViewById(R.id.swing);
        TextView editText3 = (TextView) findViewById(R.id.test_num);
        editText3.setFocusable(false);
        editText3.setClickable(false);
        View.OnClickListener listener = new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(TESTSWING1Activity.this,TESTSWING2Activity.class);   // main.java 파일에서 이벤트를 발생시켜서 test를 불러옵니다.
                intent.putExtra("id", idintent);
                intent.putExtra("name", nameintent);
                intent.putExtra("pro",prointent);
                intent.putExtra("club",clubintent);
                startActivity(intent);
            }
        };
        btn2.setOnClickListener(listener);
        */
    }

    public void back(View v){
        Intent intent = new Intent(TESTSWING1Activity.this,TESTSWINGActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);

        startActivity(intent);
    }


    public void start(View v) {

        if(test_num==3)
        {
            for(int i=0; i<3; i++) {
                correct[i]=correct[i]/3;
            }
            if(correct[0]>=correct[1] && correct[0]>=correct[2])
            {
                first_pro = "최경주";
                maxcorrect=correct[0];
                if(correct[1]>=correct[2])
                {
                    second_pro="박세리";
                    third_pro="박인비";
                }
                else
                {
                    second_pro="박인비";
                    third_pro="박세리";
                }
            }
            else if(correct[1]>=correct[0] && correct[1]>=correct[2])
            {
                first_pro = "박세리";
                maxcorrect=correct[1];
                if(correct[0]>=correct[2])
                {
                    second_pro="최경주";
                    third_pro="박인비";
                }
                else
                {
                    second_pro="박인비";
                    third_pro="최경주";
                }
            }
            else if(correct[2]>=correct[0] && correct[2]>=correct[1])
            {
                first_pro = "박인비";
                maxcorrect=correct[2];
                if(correct[0]>=correct[1])
                {
                    second_pro="최경주";
                    third_pro="박세리";
                }
                else
                {
                    second_pro="박세리";
                    third_pro="최경주";
                }
            }
            Intent intent =  new Intent(TESTSWING1Activity.this,TESTSWING2Activity.class);   // main.java 파일에서 이벤트를 발생시켜서 test를 불러옵니다.
            intent.putExtra("id", idintent);
            intent.putExtra("name", nameintent);
            intent.putExtra("pro",prointent);
            intent.putExtra("club",clubintent);
            intent.putExtra("first", first_pro);
            intent.putExtra("second",second_pro);
            intent.putExtra("third",third_pro);
            intent.putExtra("max",maxcorrect);
            startActivity(intent);
        }
        else if(test_num<3) {
            test_num++;
            String stemp = String.valueOf(test_num);
            test = (TextView) findViewById(R.id.test_num);
            test.setText(stemp + "번/3번");

            for(int i=0;i<10;i++)
            {
                Random ran = new Random();
                user_weight[i][0] = ran.nextInt(100);
                user_weight[i][1] = 100 - user_weight[i][0];
            }

            SQLiteDatabase db = dbHelper.pro_swingdata_connect_db();
            // DB에 있는 데이터를 쉽게 처리하기 위해 Cursor를 사용하여 테이블에 있는 모든 데이터 출력
            Cursor cursor = db.rawQuery("SELECT * FROM pro_swingdata where club=1", null);
            while (cursor.moveToNext()) {
                for(int i=0;i<10;i++)
                {
                    pro_weight[i][0]=cursor.getInt(i+2);
                    pro_weight[i][1]=100-pro_weight[i][0];
                }
                correct[temp]+=compare(user_weight, pro_weight);
                temp++;
            }
            /*
            String temp_correct = String.valueOf(correct[0]);
            Toast toast = Toast.makeText(getApplicationContext(),temp_correct, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
            */
            temp=0;
        }
    }

    public int compare(int mydata[][], int prodata[][]){

        //본격 비교하기 알고리즘//
        int[] comparerate = new int[10];
        int[] comparerate2 = new int[11];
        for(int i=0;i<9;i++){
            comparerate[i]=100-(Math.abs((mydata[i][0]-mydata[i+1][0])-(prodata[i][0]-prodata[i+1][0])));
            rate=rate+comparerate[i];
        }
        rate=rate/90;
        for(int j=0;j<10;j++){
            comparerate2[j]=100-(Math.abs(mydata[j][0]-prodata[j][0]));
            rate2=rate2+comparerate2[j];
        }
        rate2=rate2/100;
        result=rate*rate2;

        return result;
    }


}
