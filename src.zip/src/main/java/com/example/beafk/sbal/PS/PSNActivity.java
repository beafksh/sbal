package com.example.beafk.sbal.PS;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.beafk.sbal.Db.DBHelper;
import com.example.beafk.sbal.MainActivity;
import com.example.beafk.sbal.R;

import java.util.Random;

public class PSNActivity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String numintent;
    String prointent;
    int swingnum;
    int clubintent;
    int maxcorrect;

    DBHelper dbHelper = new DBHelper(this, "sbal", null, 1);


    private ProgressBar progBar;
    private TextView text;
    private Handler mHandler = new Handler();
    private int mProgressStatus=0;

    public int[][] user_weight = new int[10][2];
    public int[][] pro_weight = new int[10][2];

    private static int rate = 0;
    private static int rate2 = 0;
    private static int result = 0;

    TextView correct_space;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.psn);

        swingnum=1;

        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        prointent = intent.getStringExtra("pro");
        numintent = intent.getStringExtra("num");
        clubintent = intent.getIntExtra("club",1);

        //데모선수데이터 생성
        SQLiteDatabase db2 = dbHelper.pro_swingdata_connect_db();
        // DB에 있는 데이터를 쉽게 처리하기 위해 Cursor를 사용하여 테이블에 있는 모든 데이터 출력
        Cursor cursor = db2.rawQuery("SELECT * FROM pro_swingdata where club="+clubintent+" and name='"+prointent+"'", null);
        while (cursor.moveToNext()) {
            for(int i=0;i<10;i++)
            {
                pro_weight[i][0]=cursor.getInt(i+2);
                pro_weight[i][1]=100-pro_weight[i][0];
            }
        }

        TextView SN = (TextView) findViewById(R.id.psn_number);
        SN.setFocusable(false);
        SN.setClickable(false);
        SN.setText("0번/"+numintent+"번");

        TextView proname = (TextView) findViewById(R.id.psn_compare);
        proname.setText(prointent+" 선수와의 스윙 밸런스 일치도");

        progBar= (ProgressBar)findViewById(R.id.psn_progressBar);
        //text = (TextView)findViewById(R.id.textView1);

    }

    public void go_main(View v) {
        Intent intent = new Intent(PSNActivity.this,MainActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);

        startActivity(intent);
    }

    public void start(View v) {

        int correct;
        int total = Integer.parseInt(numintent);

        String temp="null";
        if(prointent.equals(temp))
        {
            String alert = "테스트 스윙 단계를 진행 필요!";
            Toast toast = Toast.makeText(getApplicationContext(),alert, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        else
        {
            if(swingnum<=total)
            {
                for(int i=0;i<10;i++) {
                    Random ran = new Random();
                    dbHelper.weight[i+2]=ran.nextInt(100);
                }
                dbHelper.user_swingdata_insert(clubintent);
                for(int i=0; i<10; i++) {
                    user_weight[i][0] = dbHelper.weight[i + 2];
                    user_weight[i][1] = 100 - dbHelper.weight[i + 2];
                }

                TextView SN = (TextView) findViewById(R.id.psn_number);
                SN.setFocusable(false);
                SN.setClickable(false);
                SN.setText(+swingnum+"번/"+numintent+"번");

                correct = compare(user_weight, pro_weight);
                if(correct>=maxcorrect)
                {
                    maxcorrect=correct;
                }
                fill_progress(correct);

                String stemp = String.valueOf(correct);
                correct_space = (TextView)findViewById(R.id.psn_correct);
                correct_space.setText(stemp+"%");
                swingnum++;
            }

            else if(swingnum>total)
            {
                String stemp = String.valueOf(maxcorrect);
                String alert = "최고 일치도는 "+stemp+"% 입니다.";
                Toast toast = Toast.makeText(getApplicationContext(),alert, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                swingnum=1;
                maxcorrect=0;
                TextView SN = (TextView) findViewById(R.id.psn_number);
                SN.setFocusable(false);
                SN.setClickable(false);
                SN.setText("0번/"+numintent+"번");
                fill_progress(0);
                correct_space = (TextView)findViewById(R.id.psn_correct);
                correct_space.setText("");
            }
        }


    }
    // 비교알고리즘

    public int compare(int mydata[][], int prodata[][]){

        //본격 비교하기 알고리즘//
        int[] comparerate = new int[10];
        int[] comparerate2 = new int[11];
        for(int i=0;i<9;i++){
            comparerate[i]=100-(Math.abs((mydata[i][0]-mydata[i+1][0])-(prodata[i][0]-prodata[i+1][0])));
            rate=rate+comparerate[i];
        }
        rate=rate/90;
        for(int j=0;j<10;j++){
            comparerate2[j]=100-(Math.abs(mydata[j][0]-prodata[j][0]));
            rate2=rate2+comparerate2[j];
        }
        rate2=rate2/100;
        result=rate*rate2;

        return result;
    }

    ////////////////////////////프로그래스바
    public void fill_progress(int correct) {

        final int pcorrect = correct;

        new Thread(new Runnable() {
            public void run() {
                final int presentage=0;
                while (mProgressStatus < pcorrect) {
                    mProgressStatus += 1;
                    // Update the progress bar
                    mHandler.post(new Runnable() {
                        public void run() {
                            progBar.setProgress(mProgressStatus);
                            //text.setText(""+mProgressStatus+"%");

                        }
                    });
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                while (mProgressStatus > pcorrect) {
                    mProgressStatus -= 1;
                    // Update the progress bar
                    mHandler.post(new Runnable() {
                        public void run() {
                            progBar.setProgress(mProgressStatus);
                            //text.setText(""+mProgressStatus+"%");

                        }
                    });
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    public void club_change(View v) {
        if(clubintent==1)
        {
            clubintent=7;
            String temp_club = String.valueOf(clubintent);
            String alert = temp_club+"번 클럽으로 전환되었습니다.";
            Toast toast = Toast.makeText(getApplicationContext(),alert, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        else if(clubintent==7)
        {
            clubintent=1;
            String temp_club = String.valueOf(clubintent);
            String alert = temp_club+"번 클럽으로 전환되었습니다.";
            Toast toast = Toast.makeText(getApplicationContext(),alert, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
    }

}
