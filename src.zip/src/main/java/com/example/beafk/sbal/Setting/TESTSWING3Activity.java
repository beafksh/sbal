package com.example.beafk.sbal.Setting;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.beafk.sbal.Db.DBHelper;
import com.example.beafk.sbal.MainActivity;
import com.example.beafk.sbal.R;

import static com.example.beafk.sbal.R.id.pro1_set;
import static com.example.beafk.sbal.R.id.pro2_set;
import static com.example.beafk.sbal.R.id.pro3_set;

/**
 * Created by jinye on 2017-03-22.
 */

public class TESTSWING3Activity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    String first;
    String second;
    String third;
    int clubintent;
    int maxcorrect;

    DBHelper dbHelper = new DBHelper(this, "sbal", null, 1);

    Button firstbtn, secondbtn, thirdbtn;
    ImageView iv1,iv2,iv3;

    View.OnClickListener set_pro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_swing3);

        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        prointent = intent.getStringExtra("pro");
        clubintent = intent.getIntExtra("club",1);
        first = intent.getStringExtra("first");
        second = intent.getStringExtra("second");
        third = intent.getStringExtra("third");
        maxcorrect = intent.getIntExtra("max",100);

        EditText editText6 = (EditText) findViewById(R.id.editText6);
        editText6.setFocusable(false);
        editText6.setClickable(false);

        EditText pro1 = (EditText) findViewById(R.id.first_pro);
        pro1.setFocusable(false);
        pro1.setClickable(false);
        pro1.setText(first+"선수");
        iv1 = (ImageView)findViewById(R.id.img_first);
        if(first.equals("최경주"))
        {
            iv1.setImageResource(R.drawable.cgj);
        }
        else if(first.equals("박세리"))
        {
            iv1.setImageResource(R.drawable.psr);
        }
        else if(first.equals("박인비"))
        {
            iv1.setImageResource(R.drawable.pib);
        }

        EditText pro2 = (EditText) findViewById(R.id.second_pro);
        pro2.setFocusable(false);
        pro2.setClickable(false);
        pro2.setText(second+"선수");
        iv2 = (ImageView)findViewById(R.id.img_second);
        if(second.equals("최경주"))
        {
            iv2.setImageResource(R.drawable.cgj);
        }
        else if(second.equals("박세리"))
        {
            iv2.setImageResource(R.drawable.psr);
        }
        else if(second.equals("박인비"))
        {
            iv2.setImageResource(R.drawable.pib);
        }

        EditText pro3 = (EditText) findViewById(R.id.thirld_pro);
        pro3.setFocusable(false);
        pro3.setClickable(false);
        pro3.setText(third+"선수");
        iv3 = (ImageView)findViewById(R.id.img_third);
        if(third.equals("최경주"))
        {
            iv3.setImageResource(R.drawable.cgj);
        }
        else if(third.equals("박세리"))
        {
            iv3.setImageResource(R.drawable.psr);
        }
        else if(third.equals("박인비"))
        {
            iv3.setImageResource(R.drawable.pib);
        }

        //////////////////////////////////버튼 리스너

        firstbtn = (Button) findViewById(pro1_set);
        secondbtn = (Button) findViewById(pro2_set);
        thirdbtn = (Button) findViewById(pro3_set);

        set_pro = new View.OnClickListener() {
            public void onClick(View v) {
               switch (v.getId()){
                    case pro1_set :
                        prointent=first;
                        int idtemp1 = Integer.parseInt(idintent);
                        SQLiteDatabase db1 = dbHelper.pro_set(idtemp1, prointent);

                        Intent intent1 = new Intent(TESTSWING3Activity.this,MainActivity.class);
                        intent1.putExtra("id", idintent);
                        intent1.putExtra("name", nameintent);
                        intent1.putExtra("pro",prointent);
                        intent1.putExtra("club",clubintent);

                        startActivity(intent1);
                        break;
                    case pro2_set:
                        prointent=second;
                        int idtemp2 = Integer.parseInt(idintent);
                        SQLiteDatabase db2 = dbHelper.pro_set(idtemp2, prointent);

                        Intent intent2 = new Intent(TESTSWING3Activity.this,MainActivity.class);
                        intent2.putExtra("id", idintent);
                        intent2.putExtra("name", nameintent);
                        intent2.putExtra("pro",prointent);
                        intent2.putExtra("club",clubintent);

                        startActivity(intent2);
                        break;
                   case pro3_set:
                       prointent=third;
                       int idtemp3 = Integer.parseInt(idintent);
                       SQLiteDatabase db3 = dbHelper.pro_set(idtemp3, prointent);

                       Intent intent3 = new Intent(TESTSWING3Activity.this,MainActivity.class);
                       intent3.putExtra("id", idintent);
                       intent3.putExtra("name", nameintent);
                       intent3.putExtra("pro",prointent);
                       intent3.putExtra("club",clubintent);
                       startActivity(intent3);
                       break;
                }

            }
        };
        firstbtn.setOnClickListener(set_pro);
        secondbtn.setOnClickListener(set_pro);
        thirdbtn.setOnClickListener(set_pro);

    }

    public void back(View v){
        Intent intent = new Intent(TESTSWING3Activity.this,TESTSWING2Activity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        intent.putExtra("first", first);
        intent.putExtra("second",second);
        intent.putExtra("third",third);
        intent.putExtra("max",maxcorrect);
        startActivity(intent);
    }

}

