package com.example.beafk.sbal.PV;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.beafk.sbal.R;

import java.util.ArrayList;

public class replayListViewAdapter extends BaseAdapter {
    // Adapter에 추가된 데이터를 저장하기 위한 ArrayList
    private ArrayList<replayListViewItem> replaylistViewItemList = new ArrayList<replayListViewItem>() ;

    // ListViewAdapter의 생성자
    public replayListViewAdapter() {

    }

    // Adapter에 사용되는 데이터의 개수를 리턴. : 필수 구현
    @Override
    public int getCount() {
        return replaylistViewItemList.size() ;
    }

    // position에 위치한 데이터를 화면에 출력하는데 사용될 View를 리턴. : 필수 구현
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        // "listview_item" Layout을 inflate하여 convertView 참조 획득.
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.replaylistrow, parent, false);
        }

        //row에 있는 뷰들을 하나의 아이템(아이콘+어플명+apk명)으로 만들어줌
        ImageView ThumbImageView = (ImageView) convertView.findViewById(R.id.replay_thumb) ;
        TextView Title = (TextView) convertView.findViewById(R.id.replay_title) ;

        // 몇 번째 순서에 들어가는지 반환
        replayListViewItem replaylistViewItem = replaylistViewItemList.get(position);

        //row에 있는 뷰들에 대한 디자인
        ThumbImageView.setImageDrawable(replaylistViewItem.getThumb());
        //첫번째,두번째 칸 텍스트 설정
        Title.setText(replaylistViewItem.getTitle());

        //첫번째,두번째 칸 색,투명도 설정
        //Title.setBackgroundColor(Color.argb(60,255, 255, 255));
        //칸 별 글꼴색 설정
        //Title.setTextColor(Color.rgb(255, 255, 255));

        return convertView;
    }

    // 지정한 위치(position)에 있는 데이터와 관계된 아이템(row)의 ID를 리턴. : 필수 구현
    @Override
    public long getItemId(int position) {
        return position ;
    }

    // 지정한 위치(position)에 있는 데이터 리턴 : 필수 구현
    @Override
    public Object getItem(int position) {
        return replaylistViewItemList.get(position) ;
    }

    // 아이템 데이터 추가를 위한 함수. 개발자가 원하는대로 작성 가능.
    public void addItem(Drawable Thumb, String title) {
        replayListViewItem item = new replayListViewItem();
        item.setThumb(Thumb);
        item.setTitle(title);
        replaylistViewItemList.add(item);
    }
}
