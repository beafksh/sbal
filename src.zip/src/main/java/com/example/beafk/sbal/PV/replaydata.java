package com.example.beafk.sbal.PV;

import android.graphics.drawable.Drawable;

/**
 * Created by beafk on 2017-03-31.
 */

public class replaydata {

    private Drawable _ThumbDrawable ; // 썸네일
    private String _title ;   // 영상명
    private String _video_address ; // 동영상 주소

    //각각의 아이템 내부에 있는 뷰들을 원하는 데이터로 세팅해주는 함수들
    public void setThumb(Drawable Thumb) {
        _ThumbDrawable = Thumb ;
    }
    public void setTitle(String title) {
        _title = title ;
    }
    public void setVideo_address(String address) {
        _video_address = address ;
    }

    //각각의 아이템 내부에 있는 뷰들의 정보를 가져오는 함수
    public Drawable getThumb() {
        return this._ThumbDrawable ;
    }
    public String getTitle() {
        return this._title ;
    }
    public String getvideo_address() {return this._video_address ;}

}


