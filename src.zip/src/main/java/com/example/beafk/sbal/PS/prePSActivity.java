package com.example.beafk.sbal.PS;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.beafk.sbal.MainActivity;
import com.example.beafk.sbal.R;

public class prePSActivity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    int clubintent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preps);

        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        prointent = intent.getStringExtra("pro");
        clubintent = intent.getIntExtra("club",1);

    }
    public void go_main(View v) {
        Intent intent = new Intent(prePSActivity.this,MainActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        startActivity(intent);
    }


    public void go_once(View v){
        Intent intent = new Intent(prePSActivity.this,PS1Activity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        startActivity(intent);
    }

    public void go_n(View v){
        Intent intent = new Intent(prePSActivity.this,prePSNActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);
        startActivity(intent);
    }

}
