package com.example.beafk.sbal.PS;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.beafk.sbal.R;

public class prePSNActivity extends AppCompatActivity {

    String idintent;
    String nameintent;
    String prointent;
    String numintent;
    int clubintent;

    Button plus, minus;
    EditText set_number;
    int num;
    View.OnClickListener set;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prepsn);

        plus = (Button) findViewById(R.id.plus);
        minus = (Button) findViewById(R.id.minus);
        set_number = (EditText) findViewById(R.id.set_psn_number);

        Intent intent = getIntent();
        idintent = intent.getStringExtra("id");
        nameintent = intent.getStringExtra("name");
        num = Integer.parseInt(set_number.getText().toString());
        numintent=String.valueOf(num);
        prointent = intent.getStringExtra("pro");
        clubintent = intent.getIntExtra("club",1);

        EditText editText = (EditText) findViewById(R.id.set_psn_number);
        editText.setFocusable(false);
        editText.setClickable(false);

        set = new View.OnClickListener() {
            public void onClick(View v) {
                num = Integer.parseInt(set_number.getText().toString());
                switch (v.getId()){
                    case R.id.plus :
                        if(num<30) {
                            num += 10;
                        }
                        break;
                    case R.id.minus:
                        if(num>10) {
                            num -= 10;
                        }
                        break;
                }
                set_number.setText(String.valueOf(num));
                numintent=String.valueOf(num);
            }
        };
        plus.setOnClickListener(set);
        minus.setOnClickListener(set);
    }


    public void psn_start(View v){
        Intent intent = new Intent(prePSNActivity.this,PSNActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("num", numintent);
        intent.putExtra("club",clubintent);

        startActivity(intent);
    }

    public void back(View v){
        Intent intent = new Intent(prePSNActivity.this,prePSActivity.class);
        intent.putExtra("id", idintent);
        intent.putExtra("name", nameintent);
        intent.putExtra("pro",prointent);
        intent.putExtra("club",clubintent);

        startActivity(intent);
    }
}
