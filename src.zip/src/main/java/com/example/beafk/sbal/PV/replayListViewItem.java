package com.example.beafk.sbal.PV;

import android.graphics.drawable.Drawable;

public class replayListViewItem {

    private Drawable _ThumbDrawable ; // 썸네일
    private String _title ;   // 영상명
    private String _video_address ; // 동영상 주소

    public void setThumb(Drawable Thumb) {
        _ThumbDrawable = Thumb ;
    }
    public void setTitle(String title) {
        _title = title ;
    }
    public void setvideo_address(String address) {
        _video_address = address ;
    }

    //각각의 아이템 내부에 있는 뷰들의 정보를 가져오는 함수
    public Drawable getThumb() {
        return this._ThumbDrawable ;
    }
    public String getTitle() {
        return this._title ;
    }
    public String getvideo_address() {return this._video_address ;}
}